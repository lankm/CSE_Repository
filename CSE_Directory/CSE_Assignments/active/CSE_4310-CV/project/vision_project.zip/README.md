# Computer Vision Project

## Members
- Landon Moon
- Parker Steach
- Gilbert Lavin
- Justin Fellows

## Materials

Project Powerpoint is included in the submitted zip file. This is the primary document we did our research on. References are included at the end of the slides.

Porject github is https://github.com/lankm/uta-vision. Details about running the code can be found there.
